/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pratica1B;

/**
 *
 * @author Joaco
 */
public class Inciso5B {
    private int Max;
    private int Min;
    private int Prom;

    public int getMax() {
        return Max;
    }

    public void setMax(int Max) {
        this.Max = Max;
    }

    public int getMin() {
        return Min;
    }

    public void setMin(int Min) {
        this.Min = Min;
    }

    public int getProm() {
        return Prom;
    }

    public void setProm(int Prom) {
        this.Prom = Prom;
    }
    
    
}
